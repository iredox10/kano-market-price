
/ functions/approve - function/ index.js
const sdk = require('node-appwrite');
const { DATABASE_ID, SHOP_APPLICATIONS_COLLECTION_ID, SHOP_OWNERS_COLLECTION_ID } = require('./constants');

module.exports = async (req, res) => {
  const client = new sdk.Client();
  const databases = new sdk.Databases(client);
  const teams = new sdk.Teams(client);

  // Check for Appwrite environment variables
  if (
    !req.variables[import.meta.env.VITE_APPWRITE_ENDPOINT] ||
    !req.variables[import.meta.env.VITE_APPWRITE_PROJECT_ID] ||
    !req.variables[import.meta.env.APPWRITE_FUNCTION_API_KEY]
  ) {
    console.warn("Environment variables are not set.");
    return res.json({ error: 'Environment variables not set.' }, 500);
  }

  client
    .setEndpoint(req.variables[import.meta.env.VITE_APPWRITE_ENDPOINT])
    .setProject(req.variables[import.meta.env.VITE_APPWRITE_PROJECT_ID])
    .setKey(req.variables[import.meta.env.APPWRITE_FUNCTION_API_KEY]);

  try {
    const payload = JSON.parse(req.payload);
    const { applicationId, userId } = payload;

    // You would add admin role checking logic here for production

    // 1. Get the application data
    const appData = await databases.getDocument(
      req.variables[DATABASE_ID],
      req.variables[SHOP_APPLICATIONS_COLLECTION_ID],
      applicationId
    );

    // 2. Add the user to the 'shopOwners' team
    // In Appwrite, roles are managed by adding users to teams.
    await teams.createMembership(
      req.variables[import.meta.env.SHOP_OWNERS_TEAM_ID], // ID of a team you create
      [], // User's roles within the team
      undefined, // Team Member URL
      appData.userEmail, // Invite by email
      userId, // User ID
      undefined, // Phone
      appData.shopName // Member's Name
    );

    // 3. Create a new document in the 'shopOwners' collection
    await databases.createDocument(
      req.variables[import.meta.env.DATABASE_ID],
      req.variables[import.meta.env.SHOP_OWNERS_COLLECTION_ID],
      userId, // Use the userId as the document ID
      {
        name: appData.shopName,
        specialty: appData.specialty,
        bio: appData.bio,
        phone: appData.phone,
        whatsapp: appData.whatsapp,
        openingHours: appData.openingHours,
        market: appData.market,
        userId: userId,
        status: 'Verified',
      }
    );

    // 4. Update the application status to 'approved'
    await databases.updateDocument(
      req.variables[import.meta.env.DATABASE_ID],
      req.variables[import.meta.env.SHOP_APPLICATIONS_COLLECTION_ID],
      applicationId,
      { status: 'approved' }
    );

    res.json({ success: true, message: `Shop ${appData.shopName} has been approved.` });

  } catch (error) {
    console.error(error);
    res.json({ error: error.message }, 500);
  }
};
